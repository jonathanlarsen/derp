var pad = require('pad-left');

console.log('hey you loaded test.js');
console.log("pad('4','4','0')", pad('4','4','0'));
